# 代购订单入库前打印状态巡检补充上传说明

## 变更背景

入库规则已调整：设计类附加项需要完成打印后才允许商品入库。

本次将前台提供的 4 个后台打印状态接口补充到「后台代购订单操作」巡检链路中，作为 `putInStock` 入库接口之前的前置节点。

## 必传文件

```text
hubbuyer/checker/api/purchase_order_ops.py
hubbuyer/config/data/purchase_order_ops.json
hubbuyer/config/rules/purchase_order_ops.json
```

## 核心变更

- `purchase_order_ops.py`
  - 新增打印状态前置步骤执行器。
  - 使用后台登录动态 token，不保存或复用浏览器抓包中的 authorization。
  - 从本轮代购订单明细动态解析 `order_detail_id`，不写死抓包示例中的 `7648`。
  - 在入库前逐个调用 `/admin_b2b/orderDetail/updatePrintStatus`。

- `purchase_order_ops.json`
  - 新增 4 个入库前置打印节点：
    - `print_sticker`: `type=sticker`
    - `print_hang_tag`: `type=hang_tag`
    - `print_wash`: `type=wash`
    - `print_fba`: `type=fba`
  - 4 个节点均默认启用，并复用同一个后台接口。

- `config/rules/purchase_order_ops.json`
  - 新增 `print_status_api` 断言，校验 HTTP 200 且 JSON `code=200`。

## 调整后的链路顺序

```text
代购订单号获取
后台登录
订单明细抽样
一键采购
一键到货
一键正品
贴纸打印状态
吊牌打印状态
洗标打印状态
FBA打印状态
入库
```

## 服务器上传与覆盖

将本包解压到服务器「全球站巡检脚本」部署根目录的上级或当前目录，确保覆盖后路径仍为：

```text
hubbuyer/checker/api/purchase_order_ops.py
hubbuyer/config/data/purchase_order_ops.json
hubbuyer/config/rules/purchase_order_ops.json
```

建议覆盖前先在服务器备份原文件：

```bash
cp -a hubbuyer/checker/api/purchase_order_ops.py hubbuyer/checker/api/purchase_order_ops.py.bak_20260828_1553
cp -a hubbuyer/config/data/purchase_order_ops.json hubbuyer/config/data/purchase_order_ops.json.bak_20260828_1553
cp -a hubbuyer/config/rules/purchase_order_ops.json hubbuyer/config/rules/purchase_order_ops.json.bak_20260828_1553
```

覆盖后执行：

```bash
cd hubbuyer
python -m py_compile checker/api/purchase_order_ops.py
python main.py
```

重点观察「后台代购订单操作」或「后台管理检查点-代购仓配」输出中是否出现：

```text
贴纸打印状态:OK
吊牌打印状态:OK
洗标打印状态:OK
FBA打印状态:OK
入库:OK
```

## 本地校验结果

已完成：

```text
python -m py_compile checker/api/purchase_order_ops.py
purchase_order_ops.json 配置解析通过
purchase_order_ops.json 规则解析通过
mock 请求确认 wash/fba/sticker/hang_tag 会携带动态 order_detail_id
```

说明：当前本地巡检环境访问线上接口被本机代理 `127.0.0.1:9` 拦截，完整线上回归需要在可直连服务器环境执行。

## 不要上传

```text
hubbuyer/config/data/current_tokens.json
hubbuyer/token/
hubbuyer/reports/
hubbuyer/logs/
hubbuyer/config/data/*orderid*.json
hubbuyer/config/data/*record*.json
hubbuyer/config/data/shipping_context.json
```

这些属于本地凭据、运行状态或巡检产物，不应同步到服务器。

