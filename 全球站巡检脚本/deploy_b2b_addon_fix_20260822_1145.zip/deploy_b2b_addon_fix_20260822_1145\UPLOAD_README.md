# B2B 附加项巡检修复上传说明

## 修复背景

生产巡检在「B2B 选择商品附加项」步骤失败，接口返回：

```text
Attempt to read property "fee_unit" on null
```

排查后确认不是设计类附加项问题，而是部分历史购买/购物车商品会带出旧的默认附加项配置，后端读取到失效价格配置导致报错。

## 必传文件

```text
hubbuyer/checker/api/B2B_Addon.py
hubbuyer/config/data/B2B_Addon.json
hubbuyer/config/data/B2B_Addon_fjxid.json
hubbuyer/config/data/add_cart_payloads.json
hubbuyer/config/data/member_pricing_complete_chain.json
```

## 可选文件

```text
hubbuyer/config/settings.py
```

仅当服务器也需要保持企业微信普通通知/异常通知关闭时上传该文件。

## 核心变更

- `B2B_Addon.py`
  - 使用 `fjx.hubbuyer.com` 所需请求头、cookie 上下文调用新版附加项接口。
  - `getCheckFjxList` 按当前购物车明细实时获取可用检品/附加项 UUID。
  - 保存附加项时过滤已知异常商品，避免历史默认附加项污染本轮报价链路。
  - 失败信息补充接口 `status/code/msg`，便于后续定位。

- `B2B_Addon.json`
  - 新增韩国站 FJX 上下文。
  - 新增异常商品排除清单，当前包含：
    `748468176862`, `937114328833`, `977375782003`, `1005031744991`, `967913069115`, `973985240957`, `1005985283846`, `635755541429`。

- `B2B_Addon_fjxid.json`
  - 更新为本轮从前台 cURL 对齐的 `JPT-CHK-002` 与 30 个可用 FJX UUID。

- `add_cart_payloads.json`
  - 淘宝加购商品替换为已验证通过的新商品：
    `1024615202405`
  - 新商品已验证：加购成功、仅检品成功、检品+30个附加项成功。

- `member_pricing_complete_chain.json`
  - 同步附加项/价格体系专项链路使用的可用 FJX 配置。

## 回归结果

执行命令：

```powershell
cd D:\test_workspace\全球站巡检脚本\hubbuyer
python main.py
```

结果：

```text
共计 18 | 成功 18 | 失败 0
```

关键链路已通过：

- B2B 加购 1688/淘宝：通过
- B2B 选择商品附加项：通过
- B2B 提交委托报价：通过
- 后台报价单审核：通过
- B2B 报价单支付：通过
- 后台代购订单审核：通过
- 后台管理检查点：通过
- 价格体系专项巡检链路：通过

最新本地报告：

```text
hubbuyer/reports/巡检报告_20260822_114145.md
```

## 不要上传

```text
hubbuyer/config/data/current_tokens.json
hubbuyer/token/
hubbuyer/reports/
hubbuyer/logs/
hubbuyer/config/data/*orderid*.json
hubbuyer/config/data/*record*.json
hubbuyer/config/data/shipping_context.json
```

这些属于本地凭据或巡检运行产物，不应同步到服务器。
