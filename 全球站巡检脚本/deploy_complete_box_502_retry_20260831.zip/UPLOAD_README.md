# completeBox 502 巡检补丁上传说明

## 问题结论

本次失败不是上个版本新增的设计类附加项打印检查点导致。

已通过的前置节点：

```text
贴纸打印状态:OK(type=sticker|ids=7689,7690,7691)
吊牌打印状态:OK(type=hang_tag|ids=7689,7690,7691)
洗标打印状态:OK(type=wash|ids=7689,7690,7691)
FBA打印状态:OK(type=fba|ids=7689,7690,7691)
入库:OK(意歆工艺品|7689x1|库位=69|采购价=4.90)
发货附加项:OK(8项)
```

实际失败点：

```text
/admin_b2b/shipOrderDetail/completeBox
装箱完成:FAIL(HTTP状态异常: 502)
```

只读查询确认发货单 `WL-KOR8-260831-004` 仍停留在打包中：

```text
ship_order_no=WL-KOR8-260831-004
ship_order.status=111
ship_status=200
pack_done_at=null
packing_total=1
ship_order_detail_id=3569
order_detail_id=7689
packed_qty=1
status=300
```

这说明前置操作已完成，最终 `completeBox` 未完成。

## 变更内容

- `purchase_order_shipping.py`
  - `_post` 支持按接口配置重试指定 HTTP 状态。
  - 失败时补充接口 URL 和响应片段，便于后续定位 502/后端异常。
- `purchase_order_shipping.json`
  - 仅给 `complete_box_api` 增加 502/503/504 重试。
  - 创建发货单、创建箱子等非幂等步骤不重试。

## 必传文件

```text
hubbuyer/checker/api/purchase_order_shipping.py
hubbuyer/config/data/purchase_order_shipping.json
```

服务器目标路径：

```text
/www/wwwroot/xierun_check_product/hubbuyer/checker/api/purchase_order_shipping.py
/www/wwwroot/xierun_check_product/hubbuyer/config/data/purchase_order_shipping.json
```

## 上传前备份

```bash
cp /www/wwwroot/xierun_check_product/hubbuyer/checker/api/purchase_order_shipping.py \
   /www/wwwroot/xierun_check_product/hubbuyer/checker/api/purchase_order_shipping.py.bak_20260831_completebox

cp /www/wwwroot/xierun_check_product/hubbuyer/config/data/purchase_order_shipping.json \
   /www/wwwroot/xierun_check_product/hubbuyer/config/data/purchase_order_shipping.json.bak_20260831_completebox
```

## 上传后验证

```bash
cd /www/wwwroot/xierun_check_product/hubbuyer
/www/server/pyporject_evn/versions/3.8.0/bin/python3 -m py_compile checker/api/purchase_order_shipping.py
/www/server/pyporject_evn/versions/3.8.0/bin/python3 -m json.tool config/data/purchase_order_shipping.json >/tmp/purchase_order_shipping_json_check.txt
```

可选：手动跑一轮巡检，观察发货链路是否走到：

```text
装箱完成:OK
移动待清算:OK
待清算扣款:OK
绑定运单号:OK
确认发货:OK
```

若仍失败，新日志会输出 `completeBox` URL 和响应片段。

## 不要上传

```text
hubbuyer/config/data/current_tokens.json
hubbuyer/token/
hubbuyer/reports/
hubbuyer/logs/
hubbuyer/config/data/*orderid*.json
hubbuyer/config/data/*record*.json
hubbuyer/config/data/shipping_context.json
```
