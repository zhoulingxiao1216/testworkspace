# 剔除 1688 停售商品上传说明

## 变更背景

生产巡检中 `B2B&D2C 商品加购接口校验` 间歇失败，失败项为 `B2B_1688`。

接口返回：

```text
code=40000
msg=该商品已停售或不存在，无法加入购物车
```

已确认停售商品：

```text
item_id=684992551107
url=https://detail.1688.com/offer/684992551107.html
```

## 必传文件

```text
hubbuyer/config/data/add_cart_payloads.json
```

服务器目标路径：

```text
/www/wwwroot/xierun_check_product/hubbuyer/config/data/add_cart_payloads.json
```

## 上传前备份

```bash
cp /www/wwwroot/xierun_check_product/hubbuyer/config/data/add_cart_payloads.json \
   /www/wwwroot/xierun_check_product/hubbuyer/config/data/add_cart_payloads.json.bak_20260831
```

## 上传后验证

确认停售商品已不存在：

```bash
grep -n "684992551107" /www/wwwroot/xierun_check_product/hubbuyer/config/data/add_cart_payloads.json
```

若无输出，说明已剔除。

校验 JSON 格式：

```bash
/www/server/pyporject_evn/versions/3.8.0/bin/python3 -m json.tool \
  /www/wwwroot/xierun_check_product/hubbuyer/config/data/add_cart_payloads.json >/tmp/add_cart_payloads_json_check.txt
```

可选：手动执行巡检验证：

```bash
cd /www/wwwroot/xierun_check_product/hubbuyer
/www/server/pyporject_evn/versions/3.8.0/bin/python3 -u main.py
```

## 不要上传

```text
hubbuyer/token/
hubbuyer/reports/
hubbuyer/logs/
hubbuyer/config/data/current_tokens.json
hubbuyer/config/data/*orderid*.json
hubbuyer/config/data/*record*.json
hubbuyer/config/data/shipping_context.json
```

以上为本地凭据或巡检运行产物，不应同步到服务器。
